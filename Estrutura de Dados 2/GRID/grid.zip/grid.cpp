#include "grid.hpp"

void inicializarGrid(Grid *g);
void incializarFila(Bucket *b);

void adicionarItem(Grid *g, Item i) {

    // Encontrar posição de inserção
    int insertX, insertY;
    acharPosicao(i, &insertX, &insertY);

    // Adicionar no bucket da poosição insertX, insertY
    adicionarFila(&g->grid[insertX][insertY], i);
}

int removerItem(Grid *g, Item i) {

    if(!pesquisa(*g, i)){
        printf("Ponto nao encontrado\n");
        return 0;
    }

    // Encontrar posição de remoção
    int posicaoX, posicaoY;
    acharPosicao(i, &posicaoX, &posicaoY);

    // Adicionar no bucket da poosição posicaoX, posicaoY
    retirarFila(&g->grid[posicaoX][posicaoY], i);
    
    return 1;
}

void adicionarFila(Bucket *b, Item i) {
    // Adicionar item na fila
}

void retirarFila(Bucket *b, Item i) {
    // Retirar item da fila
}

int pesquisarFila(Bucket *b) {
    // Pesquisando na fila
    return 1;
}

int pesquisa(Grid g, Item i) {

    // Achar posição inteira da onde estaria o item desejado
    int posicaoX, posicaoY;
    acharPosicao(i, &posicaoX, &posicaoY);

    // Procurar dentro do bucket
    int resultado = pesquisarFila(&g.grid[posicaoX][posicaoY]);

    if(resultado) return 1;
    else return 0;
}

void inputItem(Item *i) {
    printf("X: ");
    scanf("%lf", &i->x);
    printf("Y: ");
    scanf("%lf", &i->y);
}

void geral() {
    Grid g; Item insert, procura;

    // Inicialização de todas as células do grid
    inicializarGrid(&g);

    do {
        // Pegar item do usuário para inserção
        inputItem(&insert);
        adicionarItem(&g, insert);

    } while(insert.x >=0 && insert.y>=0);

    pesquisa(g, procura);
}

void acharPosicao(Item i, int *posicaoX, int *posicaoY) {
    // Neste caso, usamos o valor inteiro arredondado para baixo
    *posicaoX = floor(i.x);
    *posicaoY = floor(i.y);
}