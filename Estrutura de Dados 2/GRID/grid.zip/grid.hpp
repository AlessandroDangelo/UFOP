#ifndef GRID_HPP
#define GRID_HPP

#define TAM_GRID 5

#include <stdio.h>
#include <math.h>

typedef struct {
    double x;
    double y;
    // Outros atributos
    // ...
} Item;

typedef struct {
    Item *fila;
} Bucket;

typedef struct {
    Bucket grid[TAM_GRID][TAM_GRID];
} Grid;

void inicializarGrid(Grid *g);
void incializarFila(Bucket *b);

void acharPosicao(Item i, int *posicaoX, int *posicaoY);

void adicionarItem(Grid *g, Item i);
int removerItem(Grid *g, Item i);

void adicionarFila(Bucket *b, Item i);
void retirarFila(Bucket *b, Item i);
int pesquisarFila(Bucket *b);

int pesquisa(Grid g, Item i);
void inputItem(Item *i);
void geral();

#endif