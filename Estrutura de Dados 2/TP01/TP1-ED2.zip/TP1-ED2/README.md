# TP1-ED2
Trabalho Prático I de Estrutura de Dados II do curso de Ciência da Computação da UFOP

Membros do Projeto: Alessandro D'Angelo, Suleimane Ducure, Vinícius Cossio

# LINK DE RELATORIO COM PREMISSÃO DE EDIÇÃO
https://docs.google.com/document/d/1IS3cPEBg5JyvPY7rz-FEjIOL1NwkFIk8tQEfc-b4ZcU/edit?usp=sharing


Ultimo Commit :

Para rodar via Mekfile, digite: 'make' => vai compilar
depios depois da compilação, digite: 'make run'

Para rodar normalmente, digite: 'g++ *.cpp -o main' para compilar
em seguida : './main'

Obs: Comentei o arquivo bStar