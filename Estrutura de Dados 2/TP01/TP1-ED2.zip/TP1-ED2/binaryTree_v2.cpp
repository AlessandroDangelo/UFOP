#include "lib.h"


void insertInToBinaryTree(int size, char *fileName){

	long cont=0;

	FILE* Arvore,*dados;

	if((Arvore = fopen("Arvore.bin", "wb")) == NULL){

		cout<<"Erro na Abertura de arquivo";
		exit(1);
	}

	if((dados = fopen(fileName, "rb")) == NULL){

		cout<<"Erro na Leitura de arquivo";
		exit(1);
	}



	BinTreeNode temp;
	BinTreeNode Tree[size];

	
	while(fread(&temp, sizeof(BinTreeNode), 1, dados)==1){ //LENDO DADOS DE ARQUIVO E CONSTRUIR  A ARVORE  

		Tree[cont] = temp;
		if( cont != 0)
			setPosition(cont, temp.Reg.Registro.Chave, 0, Tree);//SETANDO POSIÇÃO DO FILHO NO NODO PAI
		cont++;
	}

	for(int i=0; i < size;i++){

		BinTreeNode aux;
		aux = Tree[i];
		fwrite(&aux, sizeof(BinTreeNode), 1, Arvore);// ESCREVENDO NO ARQUIVO A ARVORE

	}

	fclose(Arvore);
}


void setPosition(long position, long key, int i, BinTreeNode* Tree){// SETANDO POSIÇÃO DOS FILHOS NOS NODOS PAIS

	if(Tree[i].Reg.Registro.Chave == key)// SE EXISTIR A CHAVE NAO SERA ADICIONADA NA ARVORE
		return ;
	if(Tree[i].Reg.Registro.Chave < key){
		if(Tree[i].Dir == -1){
			Tree[i].Dir = position;
			return ;
		}else{

			setPosition(position, key, Tree[i].Dir, Tree);
		}
	}else{

		if(Tree[i].Esq == -1){
			Tree[i].Esq = position;
			return ;
		}else{

			setPosition(position, key, Tree[i].Esq, Tree);
		}
	}

}

void displayTeste(FILE* file){// TESTE DE VISUALIZAÇÃO DA ORGANIZAÇÃO DA ARVORE

	// FILE* saida = fopen("saida.bin", "wb");
	BinTreeNode temp;
	while(fread(&temp, sizeof(BinTreeNode), 1, file) == 1){

		cout<<temp.Esq<<" - ";
		cout<<temp.Reg.Registro.Chave;
		cout<<" - "<<temp.Dir<<"\n";
	}

}

void binaryTreeSearch(long pos, TipoRegistro* Reg, FILE* file){// BUSCA

	BinTreeNode aux;
	fseek(file, pos*sizeof(BinTreeNode), SEEK_SET);// LENDO

	fread(&aux, sizeof(BinTreeNode), 1, file);
	if(aux.Reg.Registro.Chave == Reg->Registro.Chave){// COMPARANDO COM A CHAVE DE BUSCA E SE FOR ENCONTRADA A BUSCA TERMINA

		*Reg = aux.Reg;
		return;
	}

	else if(aux.Reg.Registro.Chave < Reg->Registro.Chave){// SE A CHAVE FOR MAIOR, É PERCORRIDO O NODO DE DIREITA

		if(aux.Dir != -1){

			binaryTreeSearch(aux.Dir, Reg, file);
		}else{// CASO A CHAVE NAO EXISTIR NA ARVORE
			Reg->Registro.Chave = -1;
			return;
		}
	}else{// CASO CONTRARIO É PERCORRIDO O NODO ESQUERDO

		if(aux.Esq != -1){

			binaryTreeSearch(aux.Esq, Reg, file);
		}else{// CASO A CHAVE NAO EXISTIR NA ARVORE
			Reg->Registro.Chave = -1;
			return;
		}
	}
}	