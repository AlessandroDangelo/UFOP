// #include "lib.h"

// BinaryTree* createTree(){
//   return NULL;
// }


// int treeIsEmpty(BinaryTree* t){
//   /* Retorna 1 se a árvore for vazia e 0 caso contrário */
//   return t == NULL;

// }

// void showTree(BinaryTree* t){
  
//   printf("<"); /* notação para organizar na hora de mostrar os elementos */
//   if(!treeIsEmpty(t)) /* se a árvore não for vazia... */
//   {
//     /* Mostra os elementos em pré-ordem */
//     //printf("%d ", t->num); /* mostra a raiz */
//     showTree(t->sae); /* mostra a sae (subárvore à esquerda) */
//     showTree(t->sad); /* mostra a sad (subárvore à direita) */
//   }
//   printf(">"); /* notação para organizar na hora de mostrar os elementos */
// }

// /* Função que insere um dado na árvore */
// void insertTree(BinaryTree** t, TipoRegistro key){
//   /* Essa função insere os elementos de forma recursiva */
//   if(*t == NULL){
//     *t = (BinaryTree*)malloc(sizeof(BinaryTree)); /* Aloca memória para a estrutura */
//     (*t)->chaveDi = -1; /* Subárvore à esquerda é NULL */
//     (*t)->chaveEs = NULL;  Subárvore à direita é NULL 
//     (*t)->registo->Registro->Chave = key; /* Armazena a informação */
//   } else {
//     if(key.Registro.Chave < (*t)->registo->Registro->Chave) /* Se o número for menor então vai pra esquerda */
//     {
//       /* Percorre pela subárvore à esquerda */
//       insertTree(&(*t)->sae, key);
//     }
//     if(key.key > (*t)->key.key) /* Se o número for maior então vai pra direita */
//     {
//       /* Percorre pela subárvore à direita */
//       insertTree(&(*t)->sad, key);
//     }
//   }
// }

// /* Função que verifica se um elemento pertence ou não à árvore */
// int isInTree(BinaryTree* t, int num) {
  
//   if(treeIsEmpty(t)) { /* Se a árvore estiver vazia, então retorna 0 */
//     return 0;
//   }

//   if(t->key.key == num){
//       cout << "Chave: " << t->key.key << endl;
//       cout << "Dado1: " << t->key.data1 << endl;
//       cout << "Dado2: " << t->key.data2 << endl;
//   }
  
//   /* O operador lógico || interrompe a busca quando o elemento for encontrado */
//   return t->key.key == num || isInTree(t->sae, num) || isInTree(t->sad, num);
// }