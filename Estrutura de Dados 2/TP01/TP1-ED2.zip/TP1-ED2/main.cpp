#include "lib.h"
#include <bits/stdc++.h>

int main(int argc, char const *argv[]){	

	menuPrincipal();

	// long size = 10;
	// int keys[10] = {97,86,66,71,39,45,52,68,37,36};
	
	// char filename[] = "binary_datas.bin";
	// FILE* file = fopen(filename, "wb");
	// BinTreeNode aux;

	// for(int i=0; i<size;i++){

	// 	aux.Reg.Registro.Chave = keys[i];
	// 	aux.Reg.Registro.data1 = keys[i];
	// 	aux.Dir = -1;
	// 	aux.Esq = -1;

	// 	fwrite(&aux, sizeof(BinTreeNode), 1, file);
	// 	// char d;
	// 	// fprintf(file, "%d %d %d\n", -1, keys[i], -1);
	// }
	
	// fclose(file);

	// // FILE* filed = fopen("dado.txt", "r");
	// insertInToBinaryTree(size, filename);

	// FILE* dados;
	// if((dados = fopen("Arvore.bin", "rb")) == NULL){

	// 	cout<<"Erro na Leitura de arquivo";
	// 	exit(1);
	// }

	// displayTeste(dados);
	// TipoRegistro res;
	// res.Registro.Chave = 36;
	// binaryTreeSearch(0, &res, dados);
	// br1;

	// if(res.Registro.Chave !=-1){

	// 	cout<<"Achado";
	// }else{

	// 	cout<<"NAo achodao";
	// }

	return 0;
}