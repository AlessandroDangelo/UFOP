#include "lib.h"

typedef long TipoChave;

typedef enum {Interna, Externa} TipoIntExt;

typedef struct TipoPagina* TipoApontador;



struct tipoPaginaEstrela{
	TipoIntExt Pt;
	union{
		struct{
			int ni;
			TipoChave ri[MM];
			TipoApontadorEstrela pi[MM + 1];
		} U0;
		struct{
			int ne;
			TipoRegistro re[MM];
			TipoApontadorEstrela next;
		} U1;
	} UU;

};

void displayBStar(TipoApontadorEstrela x){
	cout<<"Entrou no display\n";
	int i;
	if(x == NULL)
		return;
	if(x->Pt == Externa){
		while(i < x->UU.U1.ne){
			cout << "Chave: " << x->UU.U1.re[i].Registro.Chave << endl;
    		cout << "Dado 1: " << x->UU.U1.re[i].Registro.data1 << endl;
    		cout << "Dado 2: " << x->UU.U1.re[i].Registro.data2 << endl;
			i++;
		}
		return;
	}
	



}

void Pesquisa(TipoRegistro *x, TipoApontadorEstrela *Ap){
	int i;
	TipoApontadorEstrela Pag;
	Pag = *Ap;
	
	if((*Ap)->Pt == Interna){
		i = 1;
		while(i < Pag->UU.U0.ni && x->Registro.Chave > Pag->UU.U0.ri[i - 1]) i++;
		if(x->Registro.Chave < Pag->UU.U0.ri[i-1])
			Pesquisa(x, &Pag->UU.U0.pi[i-1]);
		else Pesquisa(x, &Pag->UU.U0.pi[i]);
		return;
	}
	i = 1;
	while(i < Pag->UU.U1.ne && x->Registro.Chave > Pag->UU.U1.re[i-1].Registro.Chave) i++;
	if(x->Registro.Chave == Pag->UU.U1.re[i-1].Registro.Chave)
	*x = Pag->UU.U1.re[i-1];
	else cout <<"Registro nao presente na arvore\n";


}
//------------------------------------- INSERTION

void startBStar(TipoApontadorEstrela *x){
	*x = NULL;
}

void insertStar(TipoApontadorEstrela *x, TipoRegistro Reg){
	int i=0, j;
	
	TipoApontadorEstrela node1, node2;
	TipoRegistro *aux;
	

	if(*x == NULL){
		*x = (TipoPaginaEstrela*)malloc(sizeof(TipoPaginaEstrela));
		(*x)->Pt = Externa;
		(*x)->UU.U1.re[0].Registro.Chave = Reg.Registro.Chave;
		(*x)->UU.U1.re[0].Registro.data1 = Reg.Registro.data1;
		strcpy((*x)->UU.U1.re[0].Registro.data2, Reg.Registro.data2);
		(*x)->UU.U0.ni = 0;
		(*x)->UU.U1.ne = 1;
		
		return;
	}
	if((*x)->Pt == Externa && (*x)->UU.U1.ne < MM){
		
		while(Reg.Registro.Chave > (*x)->UU.U1.re[i].Registro.Chave && i < (*x)->UU.U1.ne){
			//(*aux) = (*x)->UU.U1.re[i];
			i++;
			
		}
		if(i == (*x)->UU.U1.ne){
			
			(*x)->UU.U1.re[i].Registro.Chave = Reg.Registro.Chave;
			(*x)->UU.U1.re[i].Registro.data1 = Reg.Registro.data1;
			strcpy((*x)->UU.U1.re[i].Registro.data2, Reg.Registro.data2);
			(*x)->UU.U1.ne += 1;
		}
		
	}/*
	else if((*x)->Pt == Externa && (*x)->UU.U1.ne == MM){	//folha cheia
		
			cout <<"Entrou";
			//(*x)->UU.U0.pi[0] = node1;
			//(*x)->UU.U0.pi[1] = node2;
			startBStar(&node1);
			startBStar(&node2);
			//node1 = (TipoPaginaEstrela*)malloc(sizeof(TipoPaginaEstrela));
			(*x)->Pt == Interna;
			//insertStar(&node2, Reg);
			for(i = 0; i < MM/2; i++){
				insertStar(&node1, (*x)->UU.U1.re[i]);
				cout <<"Entrou  11"<<endl;
			}
			for(i = MM/2; i < MM; i++){
				insertStar(&node2, (*x)->UU.U1.re[i]);
				cout <<"Entrou  22"<<endl;
			}
			displayBStar(node1);
			displayBStar(node2);
			adicionaFolha(x, node1);
			adicionaFolha(x, node2);
			cout <<"Entrou 2"<<endl;
			(*x)->UU.U0.ni += 2;
			//(*x)->UU.U0.pi[0] = node1;
			//(*x)->UU.U0.pi[1] = node2;
			cout << "Chave: " << (*x)->UU.U0.pi[1]->UU.U1.re[1].Registro.Chave<< endl;
    		cout << "data1: " << (*x)->UU.U0.pi[1]->UU.U1.re[1].Registro.data1<< endl;
    		cout << "data2: " << (*x)->UU.U0.pi[1]->UU.U1.re[1].Registro.data2<< endl;
			//node1->UU.U1.next = node2;
			//(*x)->UU.U0.pi[1] = node2;
			//limpaFolha(x);
			cout <<"AAAB"<<endl;

			cout << "Chave Demo: " << (*x)->UU.U0.pi[1]->UU.U1.re[0].Registro.Chave<< endl;
			cout <<"AAAC"<<endl;
    		cout << "data1: " << (*x)->UU.U0.pi[1]->UU.U1.re[0].Registro.data1<< endl;
    		cout << "data2: " << (*x)->UU.U0.pi[1]->UU.U1.re[0].Registro.data2<< endl<<endl;

			//(*x)->Pt = Interna;
			/*node1->UU.U1.next = node2;
			(*x)->UU.U0.pi[1] = node2;
			limpaFolha(x);
			(*x)->UU.U0.ri[0] = Reg.Registro.Chave;
			
	}
	else if((*x)->Pt == Interna){
		cout<<"Entrou na porra do trem"<<endl;
		for (i = 0; i < (*x)->UU.U0.ni; i++){
			if(Reg.Registro.Chave < (*x)->UU.U0.ri[i])
				insertStar(&(*x)->UU.U0.pi[i], Reg);
		}
	}
*/
}




void insereDoArquivo(FILE *file, TipoApontadorEstrela *x, Complexity *T){
	
	if((file = fopen("binary_datas.bin", "rb"))==NULL){
		cout<<"Problemas em Abrir ficheiro\n";
		exit(1);
	}
	TipoRegistro Reg;
	int i= 0;
	while(fread(&Reg, sizeof(TipoRegistro), 1, file) == 1){
		
		T->numOfTrans++;
		insertStar(x, Reg);
		
		i++;
	}
}

