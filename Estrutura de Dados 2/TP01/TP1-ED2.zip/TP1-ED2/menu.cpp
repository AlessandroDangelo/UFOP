#include "lib.h"


void displayOptions(string option, double numOption, bool should){

	if(numOption != -1){
		tab;
		cout<<option<<" ";
		int size = 50 - option.length();
		for(int i=0; i<size;i++){
			cout<<"-";
		}

		if(should){
			printf(" %lf", numOption);
		}else
		cout<<" "<<fixed<<setprecision(0)<<numOption;br2;
	}else{
		tab;
		cout<<option;br2;
	}
}



void menuPrincipal(){

	int typeSearchOption, sortType;
	long quantity, key;
	Complexity T;

	T.comparation=0;
	T.numOfTrans=0;

	char fileName[20] = "binary_datas.bin";


	cls;
	br1;

	displayOptions("Busca Sequencial Indexada", 1);
	displayOptions("Arvore Binaria de Pesquisa", 2);
	displayOptions("Arvore B", 3);
	displayOptions("Arvore B*", 4);

	br1;
	tab;
	cout<<":_";
	cin >> typeSearchOption;


	cls;
	br1;	
	displayOptions("Quantidade de Dados");

	br1;
	tab;
	cout<<":_";
	cin >> quantity;

	cls;
	br1;	
	displayOptions("Ordenado Ascendentemente", 1);
	displayOptions("Ordenado Descendentemente", 2);
	displayOptions("Aleatorio", 3);

	br1;
	tab;
	cout<<":_";
	cin >> sortType;

	datasGenerator(quantity, sortType, fileName);
	cls;
	tab;
	displayOptions("A chave");
	br1;
	tab;
	cout<<":_";
	cin >> key;


	
	TipoRegistro Reg;
	Reg.Registro.Chave = key;

	switch(typeSearchOption){

		case 1:{//ACESSO SEQUENCIAL INDEXADO
			long indexSize = (quantity/100)+1;
			TypeIndex Index[indexSize];
			T.start = clock();
			if(sortType==2){
				index_builder(fileName, Index, &T);
				sequentalIndexedSearch(&Reg, indexSize, Index, fileName,&T, false);
			}else if(sortType == 3)
				randomSeqSearch(&Reg, fileName, &T);
			else{
				index_builder(fileName, Index, &T);
				sequentalIndexedSearch(&Reg, indexSize, Index, fileName,&T, true);
			}
			break;
		}

		case 2:{ //ARVORE BINARIA

			FILE* file;
			if((file = fopen("Arvore.bin", "rb")) == NULL){
				cls;
				displayOptions("O arquivo nao pode ser lido");
				exit(1);
			}

			T.start = clock();
			char Arvore[] = "Arvore.bin";
			insertInToBinaryTree(quantity, fileName);
			// binaryTreeSearch(0, &Reg, file);
			T.end = clock();
			break;
		}

		case 3:{
			TipoApontador Tree = (TipoApontador)malloc(sizeof(TipoPagina));
			tree_starter(&Tree);
			T.start = clock();
			dataLoader(&Tree, fileName);
			bTreeSearch(&Reg, Tree, &T);
			break;
		}

		case 4:{

			TipoApontadorEstrela bStar;
			TipoRegistro Reg;
			Reg.Registro.Chave = 18461;
			startBStar(&bStar);
			FILE *arq;
			T.start = clock();
			insereDoArquivo(arq, &bStar, &T);
			cls;
			displayBStar(bStar);
			Pesquisa(&Reg, &bStar);
			
			cout << "Chave: " << Reg.Registro.Chave << endl;
    		cout << "Dado 1: " << Reg.Registro.data1 << endl;
    		cout << "Dado 2 DA BUSCA: " << Reg.Registro.data2 << endl;
			break;
		}

		default:{

			displayOptions("Opcao Errada!");
			break;
		}
	}

	T.end = clock();
	T.time = ((double)T.end - T.start) / double(CLOCKS_PER_SEC);
	complexityDiscription(&T, Reg);
}


void complexityDiscription(Complexity *T, TipoRegistro Reg){

	cls;
	br1;
	displayOptions("O tempo da busca: ", T->time, true);
	displayOptions("O Numero de comparaçoes: ", (double)T->comparation);
	if(T->numOfTrans != 0)
		displayOptions("O Numero de trasferencias: ", (double)T->numOfTrans);

	if(Reg.Registro.Chave != -1){

		br1;		
		displayOptions("A chave: ", (double)Reg.Registro.Chave);
		displayOptions("O Dado1: ", (double)Reg.Registro.data1);
		displayOptions("O Dado2: ");
		tab;
		cout<<Reg.Registro.data2;
	}else{
		tab;cout<<"Ops nao achado ";
	}
}