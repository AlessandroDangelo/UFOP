#include <ios>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

/*!
    A function that checks the amount of memory that is in usage.                      
*/
void memory_usage(double& vm_usage, double& resident_set);