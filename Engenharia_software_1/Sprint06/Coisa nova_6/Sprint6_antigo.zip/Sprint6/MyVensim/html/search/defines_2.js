var searchData=
[
  ['logistic_240',['LOGISTIC',['../functional__tests_8h.html#a4dd5812520f0d909b360c24636086bee',1,'LOGISTIC():&#160;functional_tests.h'],['../unit__model_8h.html#a4dd5812520f0d909b360c24636086bee',1,'LOGISTIC():&#160;unit_model.h']]]
];
