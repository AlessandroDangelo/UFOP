var searchData=
[
  ['body_2',['Body',['../class_body.html',1,'Body'],['../class_body.html#a7727b0d8c998bbc2942e4c802e31e2eb',1,'Body::Body()'],['../class_body.html#ad7fa496772479f2d3debe3c1ea0e8c1b',1,'Body::Body(const Body &amp;)']]]
];
