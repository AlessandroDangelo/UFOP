var searchData=
[
  ['logistic_173',['Logistic',['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic::Logistic()'],['../class_logistic.html#ae137bd4c8e3d59f2860b89b4e8a5f43c',1,'Logistic::Logistic()']]],
  ['logisticalfuncionaltest_174',['logisticalFuncionalTest',['../functional__tests_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;functional_tests.cpp'],['../functional__tests_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;functional_tests.cpp']]]
];
