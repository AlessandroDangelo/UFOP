var searchData=
[
  ['logistic_124',['Logistic',['../class_logistic.html',1,'']]]
];
