var searchData=
[
  ['add_152',['add',['../class_model.html#a70362afdd9db6268b4adaedfeddb2935',1,'Model::add(System *)=0'],['../class_model.html#ac1e19f5fcc4ced9defbfe2847a26ff33',1,'Model::add(Flow *)=0'],['../class_model_body.html#a57cfc0cee3191cf9def427701238df77',1,'ModelBody::add(System *)'],['../class_model_body.html#aa356e789203429c578536e014999a1bf',1,'ModelBody::add(Flow *)'],['../class_model_body.html#a9bcec0730ddcf1f27ca79882f9308cd8',1,'ModelBody::add(Model *model)'],['../class_model_handle.html#acf6ea36ccd2ee6d375c988bc71dcfcdd',1,'ModelHandle::add(System *system)'],['../class_model_handle.html#a1c2fe71daa814c09442b735a81f9ba53',1,'ModelHandle::add(Flow *flow)'],['../class_model_handle.html#a6473ef1915fe407a6866fdb9c594685b',1,'ModelHandle::add(Model *model)']]],
  ['attach_153',['attach',['../class_body.html#a5d53322c76a6952d096cb7564ac86db1',1,'Body']]]
];
