#include <assert.h>
#include "model.h"
#include "flow.h"
#include "system.h"

using namespace std;

int main (){  return 0; }