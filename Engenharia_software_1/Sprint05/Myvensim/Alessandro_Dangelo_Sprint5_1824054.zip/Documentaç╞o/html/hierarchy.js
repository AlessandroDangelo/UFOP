var hierarchy =
[
    [ "Flow", "classFlow.html", [
      [ "FlowImpl", "classFlowImpl.html", [
        [ "ComplexFlowF", "classComplexFlowF.html", null ],
        [ "ComplexFlowG", "classComplexFlowG.html", null ],
        [ "ComplexFlowR", "classComplexFlowR.html", null ],
        [ "ComplexFlowT", "classComplexFlowT.html", null ],
        [ "ComplexFlowU", "classComplexFlowU.html", null ],
        [ "ComplexFlowV", "classComplexFlowV.html", null ],
        [ "ExponencialFlow", "classExponencialFlow.html", null ],
        [ "ExponencialFlow", "classExponencialFlow.html", null ],
        [ "LogisticFlow", "classLogisticFlow.html", null ]
      ] ]
    ] ],
    [ "Model", "classModel.html", [
      [ "ModelImpl", "classModelImpl.html", null ]
    ] ],
    [ "System", "classSystem.html", [
      [ "SystemImpl", "classSystemImpl.html", null ]
    ] ],
    [ "UnitFlow", "classUnitFlow.html", null ],
    [ "UnitModel", "classUnitModel.html", null ],
    [ "UnitSystem", "classUnitSystem.html", null ]
];