var unit__tests_8cpp =
[
    [ "run_unit_tests_globals", "unit__tests_8cpp.html#aaef0e580ac1123f30a7c742b9b73e51a", null ],
    [ "unit_test_global_divisionOperator", "unit__tests_8cpp.html#aad80f5d66ac51c8a3e9a598215920025", null ],
    [ "unit_test_global_minusOperator", "unit__tests_8cpp.html#ae82c7071f4a8155ff63896b666358815", null ],
    [ "unit_test_global_sumOperator", "unit__tests_8cpp.html#a1593182e5a0018da6d26a8807ea59aeb", null ],
    [ "unit_test_global_timesOperator", "unit__tests_8cpp.html#a28477ad1f63590071a67be46d47c9a23", null ]
];