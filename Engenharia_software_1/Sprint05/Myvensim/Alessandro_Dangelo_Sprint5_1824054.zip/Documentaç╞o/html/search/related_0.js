var searchData=
[
  ['unitmodel_0',['UnitModel',['../classModel.html#acfe6145ac71b7c6b9065c61d09de0131',1,'Model::UnitModel()'],['../classModelImpl.html#acfe6145ac71b7c6b9065c61d09de0131',1,'ModelImpl::UnitModel()']]]
];
