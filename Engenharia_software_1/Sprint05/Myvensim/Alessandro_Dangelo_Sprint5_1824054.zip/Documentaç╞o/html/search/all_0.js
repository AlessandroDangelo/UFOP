var searchData=
[
  ['add_0',['add',['../classModel.html#a94c8319fa87ab9f33a4ac2b362837e5d',1,'Model::add(System *sys)=0'],['../classModel.html#ab7df81041f62f049cfc6e4d50dcaf721',1,'Model::add(Flow *flow)=0'],['../classModelImpl.html#a71fdc6f260548487d5732c97a65d016b',1,'ModelImpl::add(System *sys)'],['../classModelImpl.html#a3b71fb4f8f2b4933104f03a91138a758',1,'ModelImpl::add(Flow *flow)']]]
];
