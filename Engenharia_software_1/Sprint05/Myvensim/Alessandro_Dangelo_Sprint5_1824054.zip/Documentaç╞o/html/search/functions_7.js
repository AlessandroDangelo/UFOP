var searchData=
[
  ['logisticalfuncionaltest_0',['logisticalFuncionalTest',['../funcional__tests_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_tests.cpp'],['../funcional__tests_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_tests.cpp']]],
  ['logisticflow_1',['LogisticFlow',['../classLogisticFlow.html#a6e4d2bf2b778fb3bf70ca6e85a73940d',1,'LogisticFlow']]]
];
