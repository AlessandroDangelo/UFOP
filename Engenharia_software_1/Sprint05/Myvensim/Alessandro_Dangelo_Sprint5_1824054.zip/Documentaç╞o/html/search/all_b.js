var searchData=
[
  ['qntd_0',['qntd',['../classModelImpl.html#a83020b28e438b82ccf821e751282ff79',1,'ModelImpl']]]
];
