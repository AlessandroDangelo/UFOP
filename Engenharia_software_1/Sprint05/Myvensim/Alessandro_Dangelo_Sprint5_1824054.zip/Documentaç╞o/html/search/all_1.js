var searchData=
[
  ['beginflows_0',['beginFlows',['../classModel.html#a4c21fa615edc5d7b8a9696fe090707a4',1,'Model::beginFlows()'],['../classModelImpl.html#a04d4234a1c69c7164f628fec763f8f20',1,'ModelImpl::beginFlows()']]],
  ['beginsystems_1',['beginSystems',['../classModel.html#af44c12bce2645f91b796e750ddbacbd2',1,'Model::beginSystems()'],['../classModelImpl.html#a6a4d492d29b4af77b294ee8031bae6f5',1,'ModelImpl::beginSystems()']]]
];
