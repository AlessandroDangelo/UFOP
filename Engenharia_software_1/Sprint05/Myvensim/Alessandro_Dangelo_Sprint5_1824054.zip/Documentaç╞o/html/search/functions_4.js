var searchData=
[
  ['flowimpl_0',['FlowImpl',['../classFlowImpl.html#ab6633e6def4d5b66b3d7fc84004be98e',1,'FlowImpl::FlowImpl(const Flow &amp;flow)'],['../classFlowImpl.html#ac3dd23e6cdfaeab86cd588aec58c4aac',1,'FlowImpl::FlowImpl(string name=&quot;&quot;, System *source=NULL, System *target=NULL)']]]
];
