var classUnitFlow =
[
    [ "UnitFlow", "classUnitFlow.html#a735d23997080361a961ad7a30e381a4a", null ],
    [ "~UnitFlow", "classUnitFlow.html#ae083b5e6ee9f139cedf21d9867074cd1", null ],
    [ "unit_flow_assingmentOperator", "classUnitFlow.html#a4352ea66699a72da26e983d37a74c368", null ],
    [ "unit_flow_copy_constructor", "classUnitFlow.html#a63951bd806985d20afee08a29f70ab15", null ]
];