#include "unit_system.h"
#include "unit_flow.h"
#include "unit_model.h"

int main (){

    run_unit_test_System();
    run_unit_test_Flow();
    run_unit_test_Model();

    return 0;
}