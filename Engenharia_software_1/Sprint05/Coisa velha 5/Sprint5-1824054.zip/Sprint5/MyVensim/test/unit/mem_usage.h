#include <ios>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void mem_usage(double& vm_usage, double& resident_set);