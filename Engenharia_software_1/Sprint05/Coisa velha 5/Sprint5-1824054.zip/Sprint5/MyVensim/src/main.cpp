#include <assert.h>
#include "./lib/system.h"

int main () { return 0; }