var searchData=
[
  ['name_38',['name',['../class_system___imp.html#a7d07126fe27dbaf7ee7d4c9ceac6c0eb',1,'System_Imp']]]
];
