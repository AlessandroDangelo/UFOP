var searchData=
[
  ['logistic_93',['Logistic',['../class_logistic.html',1,'']]]
];
